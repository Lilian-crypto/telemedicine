<?php
$dbuser = "root";
$dbpass = "";
$host   = "localhost";
$db     = "hmisphp";

// Create connection
$mysqli = new mysqli($host, $dbuser, $dbpass, $db);

// Check if connection works
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
} else {
    echo "✅ Database Connected Successfully!";
}
?>
