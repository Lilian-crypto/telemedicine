<?php
$servername = "sql304.infinityfree.com"; // Your InfinityFree MySQL hostname
$username = "if0_38645621"; // Your MySQL username
$password = ""; // Your MySQL password (check your cPanel)
$dbname = "if0_38645621_hmisphp"; // Your database name (check cPanel)

require_once 'send_email.php'; // Include email function

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check if connection works
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
} else {
    echo "✅ Database Connected Successfully!";
}
?>
