<?php
include 'backend/doc/assets/inc/config.php'; // If you want to use the doc config
// OR
// include 'backend/admin/assets/inc/config.php'; // If you want to use the admin config
?>
