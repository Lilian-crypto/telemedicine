<footer class="footer footer-alt">
            2025 - <?php echo date ('Y');?> &copy; Telemedicine.</a> 
</footer>