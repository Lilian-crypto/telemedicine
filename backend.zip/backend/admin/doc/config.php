<?php
// Database connection settings
$host = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'hmisphp';

// Create a new MySQLi connection
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);

// Check for connection errors
if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}
?>
