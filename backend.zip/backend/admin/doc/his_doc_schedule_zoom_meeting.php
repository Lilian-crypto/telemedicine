<?php
    session_start();
    include('assets/inc/config.php');

    // Schedule Zoom Meeting
    if (isset($_POST['schedule_zoom_meeting'])) {
        $doctor_id = $_SESSION['doc_id'];
        $topic = $_POST['meeting_title']; // Changed to match the actual column name
        $meeting_date = $_POST['meeting_date'];
        $meeting_time = $_POST['meeting_time'];
        $duration = $_POST['meeting_duration'];
        $meeting_link = $_POST['meeting_link'];

        // Prepare SQL query
        $sql = "INSERT INTO his_zoom_meetings (topic, doctor_id, meeting_date, meeting_time, duration, meeting_id) 
                VALUES (?, ?, ?, ?, ?, ?)";
        
        if ($stmt = $mysqli->prepare($sql)) {
            $stmt->bind_param('sissis', $topic, $doctor_id, $meeting_date, $meeting_time, $duration, $meeting_link);
            if ($stmt->execute()) {
                echo "<script>alert('Meeting Scheduled Successfully!');</script>";
            } else {
                echo "<script>alert('Error: " . $stmt->error . "');</script>";
            }
            $stmt->close();
        } else {
            echo "<script>alert('Database Error: " . $mysqli->error . "');</script>";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
    <?php include('assets/inc/head.php'); ?>
    <body>
        <div id="wrapper">
            <?php include("assets/inc/nav.php"); ?>
            <?php include("assets/inc/sidebar.php"); ?>

            <div class="content-page">
                <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Schedule Zoom Meeting</h4>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Schedule a New Meeting</h4>
                                        <form method="post">
                                            <div class="form-group">
                                                <label>Meeting Title</label>
                                                <input type="text" name="meeting_title" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Meeting Date</label>
                                                <input type="date" name="meeting_date" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Meeting Time</label>
                                                <input type="time" name="meeting_time" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Duration (mins)</label>
                                                <input type="number" name="meeting_duration" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Meeting Link</label>
                                                <input type="url" name="meeting_link" class="form-control" required>
                                            </div>
                                            <button type="submit" name="schedule_zoom_meeting" class="btn btn-primary">Schedule Meeting</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php include('assets/inc/footer.php'); ?>
            </div>
        </div>
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/js/app.min.js"></script>
    </body>
</html>  
