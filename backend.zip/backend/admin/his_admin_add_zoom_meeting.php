<?php
    session_start();
    include('assets/inc/config.php');

    if (isset($_POST['add_zoom_meeting'])) {
        $meeting_title = $_POST['meeting_title'];
        $meeting_date = $_POST['meeting_date'];
        $meeting_time = $_POST['meeting_time'];
        $meeting_duration = $_POST['meeting_duration'];
        $meeting_link = $_POST['meeting_link'];
        $meeting_passcode = $_POST['meeting_passcode'];
        $host_email = $_POST['host_email'];
        $meeting_description = $_POST['meeting_description'];
        $email_recipients = $_POST['email_recipients'];
        
        $query = "INSERT INTO his_zoom_meetings (meeting_title, meeting_date, meeting_time, meeting_duration, meeting_link, meeting_passcode, host_email, meeting_description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('ssssssss', $meeting_title, $meeting_date, $meeting_time, $meeting_duration, $meeting_link, $meeting_passcode, $host_email, $meeting_description);
        $stmt->execute();

        if ($stmt) {
            $success = "Zoom Meeting Added Successfully";
            
            // Send Email Notification
            $subject = "New Zoom Meeting Scheduled";
            $message = "A new Zoom meeting has been scheduled:\nTitle: $meeting_title\nDate: $meeting_date\nTime: $meeting_time\nDuration: $meeting_duration mins\nHost: $host_email\nJoin Link: $meeting_link\nPasscode: $meeting_passcode\nDescription: $meeting_description";
            $headers = "From: admin@hospital.com";
            mail($email_recipients, $subject, $message, $headers);
        } else {
            $err = "Error! Try Again";
        }
    }

    if (isset($_POST['edit_zoom_meeting'])) {
        $meeting_id = $_POST['meeting_id'];
        $meeting_title = $_POST['meeting_title'];
        $meeting_date = $_POST['meeting_date'];
        $meeting_time = $_POST['meeting_time'];
        $meeting_duration = $_POST['meeting_duration'];
        $meeting_link = $_POST['meeting_link'];
        $meeting_passcode = $_POST['meeting_passcode'];
        $host_email = $_POST['host_email'];
        $meeting_description = $_POST['meeting_description'];
        
        $query = "UPDATE his_zoom_meetings SET meeting_title=?, meeting_date=?, meeting_time=?, meeting_duration=?, meeting_link=?, meeting_passcode=?, host_email=?, meeting_description=? WHERE id=?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('ssssssssi', $meeting_title, $meeting_date, $meeting_time, $meeting_duration, $meeting_link, $meeting_passcode, $host_email, $meeting_description, $meeting_id);
        $stmt->execute();

        if ($stmt) {
            $success = "Zoom Meeting Updated Successfully";
        } else {
            $err = "Error! Try Again";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
    <?php include('assets/inc/head.php'); ?>
    <body>
        <div id="wrapper">
            <?php include("assets/inc/nav.php"); ?>
            <?php include("assets/inc/sidebar.php"); ?>

            <div class="content-page">
                <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Manage Zoom Meetings</h4>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Add Zoom Meeting</h4>
                                        <form method="post">
                                            <div class="form-group">
                                                <label>Meeting Title</label>
                                                <input type="text" name="meeting_title" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Meeting Date</label>
                                                <input type="date" name="meeting_date" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Meeting Time</label>
                                                <input type="time" name="meeting_time" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Meeting Duration (minutes)</label>
                                                <input type="number" name="meeting_duration" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Zoom Meeting Link</label>
                                                <input type="url" name="meeting_link" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Meeting Passcode</label>
                                                <input type="text" name="meeting_passcode" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Host Email</label>
                                                <input type="email" name="host_email" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Meeting Description</label>
                                                <textarea name="meeting_description" class="form-control" required></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Email Recipients</label>
                                                <input type="email" name="email_recipients" class="form-control" required>
                                            </div>
                                            <button type="submit" name="add_zoom_meeting" class="btn btn-primary">Add Meeting</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php include('assets/inc/footer.php'); ?>
            </div>
        </div>
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/js/app.min.js"></script>
    </body>
</html>
