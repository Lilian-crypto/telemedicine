<?php  
session_start();
include('assets/inc/config.php'); // Ensure database connection

// Patient registration logic
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect patient details from the form
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $patient_type = $_POST['patient_type'];  // New field
    $patient_ailment = $_POST['patient_ailment'];  // New field
    $patient_age = $_POST['patient_age'];  // New field

    // Hash the password before storing it
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if the email already exists in the database
    $email_check_query = "SELECT patient_id FROM his_patients WHERE patient_email = ?";
    $stmt = $mysqli->prepare($email_check_query);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Display error message if email already exists
        echo "<script type='text/javascript'>
                window.onload = function() {
                    var errorMessage = document.createElement('div');
                    errorMessage.innerHTML = 'Error: A patient with this email already exists.';
                    errorMessage.style.position = 'fixed';
                    errorMessage.style.top = '50%';
                    errorMessage.style.left = '50%';
                    errorMessage.style.transform = 'translate(-50%, -50%)';
                    errorMessage.style.padding = '20px';
                    errorMessage.style.backgroundColor = '#dc3545';
                    errorMessage.style.color = '#fff';
                    errorMessage.style.fontSize = '18px';
                    errorMessage.style.fontWeight = 'bold';
                    errorMessage.style.borderRadius = '8px';
                    errorMessage.style.boxShadow = '0 0 10px rgba(0,0,0,0.5)';
                    errorMessage.style.animation = 'zoomOut 2s ease-in-out forwards';
                    document.body.appendChild(errorMessage);

                    setTimeout(function() {
                        errorMessage.style.display = 'none';
                    }, 2500);
                }
              </script>";
        exit;
    }

    // Insert the new patient into the database
    $insert_query = "INSERT INTO his_patients (patient_first_name, patient_last_name, patient_phone, patient_address, patient_gender, date_of_birth, patient_email, patient_pwd, patient_type, patient_ailment, patient_age) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $mysqli->prepare($insert_query);
    $stmt->bind_param('ssssssssssi', $first_name, $last_name, $phone, $address, $gender, $dob, $email, $hashed_password, $patient_type, $patient_ailment, $patient_age);

    if ($stmt->execute()) {
        // Display success message if patient is successfully registered
        echo "<script type='text/javascript'>
                window.onload = function() {
                    var successMessage = document.createElement('div');
                    successMessage.innerHTML = 'Patient successfully registered.';
                    successMessage.style.position = 'fixed';
                    successMessage.style.top = '50%';
                    successMessage.style.left = '50%';
                    successMessage.style.transform = 'translate(-50%, -50%)';
                    successMessage.style.padding = '20px';
                    successMessage.style.backgroundColor = '#28a745';
                    successMessage.style.color = '#fff';
                    successMessage.style.fontSize = '18px';
                    successMessage.style.fontWeight = 'bold';
                    successMessage.style.borderRadius = '8px';
                    successMessage.style.boxShadow = '0 0 10px rgba(0,0,0,0.5)';
                    successMessage.style.animation = 'zoomOut 2s ease-in-out forwards';
                    document.body.appendChild(successMessage);

                    setTimeout(function() {
                        successMessage.style.display = 'none';
                    }, 2500);
                }
              </script>";
        exit;
    } else {
        die("Error: Unable to register patient. " . $stmt->error);
    }
}
?>

<!-- Register Patient Form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Patient</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* CSS Animation for Zoom Out Effect */
        @keyframes zoomOut {
            0% {
                transform: scale(1);
                opacity: 1;
            }
            100% {
                transform: scale(0);
                opacity: 0;
            }
        }
    </style>
</head>
<body>

<div class="container mt-4">
    <h2>Register New Patient</h2>
    <form method="POST">
        <div class="form-group">
            <label for="first_name">First Name</label>
            <input type="text" name="first_name" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="last_name">Last Name</label>
            <input type="text" name="last_name" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="phone">Phone</label>
            <input type="text" name="phone" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="address">Address</label>
            <input type="text" name="address" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="gender">Gender</label>
            <select name="gender" class="form-control" required>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
        </div>
        <div class="form-group">
            <label for="dob">Date of Birth</label>
            <input type="date" name="dob" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="patient_type">Patient Type</label>
            <input type="text" name="patient_type" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="patient_ailment">Patient Ailment</label>
            <input type="text" name="patient_ailment" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="patient_age">Patient Age</label>
            <input type="number" name="patient_age" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Register Patient</button>
    </form>
</div>

</body>
</html>
