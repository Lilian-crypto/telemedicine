<?php
session_start();
include('assets/inc/config.php');
include('assets/inc/checklogin.php');
check_login();

$doc_id = $_SESSION['doc_id'];

if (!isset($_GET['pat_number']) || !isset($_GET['pat_id'])) {
    die("Patient data is missing.");
}

$pat_number = $_GET['pat_number'];
$pat_id = $_GET['pat_id'];

$ret = "SELECT * FROM his_patients WHERE patient_id=?";
$stmt = $mysqli->prepare($ret);
$stmt->bind_param('i', $pat_id);
$stmt->execute();
$res = $stmt->get_result();
$patient = $res->fetch_object();
?>

<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php'); ?>

<body>
    <div id="wrapper">
        <?php include("assets/inc/nav.php"); ?>
        <?php include("assets/inc/sidebar.php"); ?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Dashboard</a></li>
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Patients</a></li>
                                        <li class="breadcrumb-item active">View Patients</li>
                                    </ol>
                                </div>
                                <h4 class="page-title"><?php echo $patient->patient_first_name . " " . $patient->patient_last_name; ?>'s Profile</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-4 col-xl-4">
                            <div class="card-box text-center">
                                <img src="assets/images/users/patient.png" class="rounded-circle avatar-lg img-thumbnail" alt="profile-image">

                                <div class="text-left mt-3">
                                    <p><strong>Full Name: </strong> <?php echo $patient->patient_first_name . " " . $patient->patient_last_name; ?></p>
                                    <p><strong>Mobile: </strong> <?php echo $patient->patient_phone; ?></p>
                                    <p><strong>Address: </strong> <?php echo $patient->patient_address; ?></p>
                                    <p><strong>Age: </strong> <?php echo $patient->patient_age; ?> Years</p>
                                    <p><strong>Ailment: </strong> <?php echo $patient->patient_ailment; ?></p>
                                    <p><strong>Date Recorded: </strong> <?php echo date("d/m/Y - h:m", strtotime($patient->created_at)); ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-8 col-xl-8">
                            <div class="card-box">
                                <ul class="nav nav-pills navtab-bg nav-justified">
                                    <li class="nav-item">
                                        <a href="#prescription" data-toggle="tab" class="nav-link active">Prescription</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#vitals" data-toggle="tab" class="nav-link">Vitals</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#lab_records" data-toggle="tab" class="nav-link">Lab Records</a>
                                    </li>
                                </ul>

                                <div class="tab-content">
                                    <!-- Prescription Tab -->
                                    <div class="tab-pane show active" id="prescription">
                                        <ul class="list-unstyled timeline-sm">
                                            <?php
                                            $ret = "SELECT * FROM prescriptions WHERE patient_id=?";
                                            $stmt = $mysqli->prepare($ret);
                                            $stmt->bind_param('i', $pat_id);
                                            $stmt->execute();
                                            $res = $stmt->get_result();
                                            while ($row = $res->fetch_object()) {
                                            ?>
                                                <li class="timeline-sm-item">
                                                    <span class="timeline-sm-date"><?php echo date("Y-m-d", strtotime($row->prescribed_date)); ?></span>
                                                    <h5><?php echo $row->patient_ailment; ?></h5>
                                                    <p><?php echo $row->instructions; ?></p>
                                                </li>
                                            <?php } ?>
                                        </ul>
                                    </div>

                                    <!-- Vitals Tab -->
                                    <div class="tab-pane" id="vitals">
                                        <table class="table table-borderless">
                                            <thead>
                                                <tr>
                                                    <th>Body Temperature</th>
                                                    <th>Heart Rate</th>
                                                    <th>Respiratory Rate</th>
                                                    <th>Blood Pressure</th>
                                                    <th>Date Recorded</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $ret = "SELECT * FROM his_vitals WHERE vit_pat_number=?";
                                                $stmt = $mysqli->prepare($ret);
                                                $stmt->bind_param('s', $pat_number);
                                                $stmt->execute();
                                                $res = $stmt->get_result();
                                                while ($row = $res->fetch_object()) {
                                                ?>
                                                    <tr>
                                                        <td><?php echo $row->vit_bodytemp; ?>°C</td>
                                                        <td><?php echo $row->vit_heartpulse; ?> BPM</td>
                                                        <td><?php echo $row->vit_resprate; ?> bpm</td>
                                                        <td><?php echo $row->vit_bloodpress; ?> mmHg</td>
                                                        <td><?php echo date("Y-m-d", strtotime($row->vit_daterec)); ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Lab Records Tab -->
                                    <div class="tab-pane" id="lab_records">
                                        <ul class="list-unstyled timeline-sm">
                                            <?php
                                            $ret = "SELECT * FROM his_laboratory WHERE lab_pat_number=?";
                                            $stmt = $mysqli->prepare($ret);
                                            $stmt->bind_param('s', $pat_number);
                                            $stmt->execute();
                                            $res = $stmt->get_result();
                                            while ($row = $res->fetch_object()) {
                                            ?>
                                                <li class="timeline-sm-item">
                                                    <span class="timeline-sm-date"><?php echo date("Y-m-d", strtotime($row->lab_date_rec)); ?></span>
                                                    <h5><?php echo $row->lab_pat_ailment; ?></h5>
                                                    <p><?php echo $row->lab_pat_tests; ?></p>
                                                    <p><strong>Results:</strong> <?php echo $row->lab_pat_results; ?></p>
                                                </li>
                                            <?php } ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('assets/inc/footer.php'); ?>
        </div>
    </div>

    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>
</html>
