<?php
session_start();
include('assets/inc/config.php');

if (isset($_POST['delete_zoom_meeting'])) {
    $meeting_id = filter_input(INPUT_POST, 'meeting_id', FILTER_SANITIZE_NUMBER_INT);

    if ($meeting_id) {
        $query = "DELETE FROM his_zoom_meetings WHERE id=?";
        $stmt = $mysqli->prepare($query);

        if ($stmt) {
            $stmt->bind_param('i', $meeting_id);
            if ($stmt->execute()) {
                $_SESSION['success_message'] = "Meeting deleted successfully.";
            } else {
                $_SESSION['error_message'] = "Error deleting meeting: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $_SESSION['error_message'] = "Error preparing statement: " . $mysqli->error;
        }
    } else {
        $_SESSION['error_message'] = "Invalid meeting ID.";
    }

    header("Location: manage_zoom_meetings.php"); // Redirect to refresh the page
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php'); ?>

<body>
    <div id="wrapper">
        <?php include("assets/inc/nav.php"); ?>
        <?php include("assets/inc/sidebar.php"); ?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Manage Zoom Meetings</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">Scheduled Zoom Meetings</h4>
                                    <?php
                                    if (isset($_SESSION['success_message'])) {
                                        echo '<div class="alert alert-success">' . $_SESSION['success_message'] . '</div>';
                                        unset($_SESSION['success_message']); // Clear the message
                                    }
                                    if (isset($_SESSION['error_message'])) {
                                        echo '<div class="alert alert-danger">' . $_SESSION['error_message'] . '</div>';
                                        unset($_SESSION['error_message']); // Clear the message
                                    }
                                    ?>
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Title</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                                <th>Duration</th>
                                                <th>Link</th>
                                                <th>Host Email</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $query = "SELECT * FROM his_zoom_meetings";
                                            $result = $mysqli->query($query);

                                            if ($result) {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . htmlspecialchars($row['meeting_title']) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['meeting_date']) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['meeting_time']) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['meeting_duration']) . " mins</td>";
                                                    echo "<td><a href='" . htmlspecialchars($row['meeting_link']) . "' target='_blank'>Join</a></td>";
                                                    echo "<td>" . htmlspecialchars($row['host_email']) . "</td>";
                                                    echo "<td>
                                                                <form method='post' style='display:inline;' onsubmit=\"return confirm('Are you sure you want to delete this meeting?');\">
                                                                    <input type='hidden' name='meeting_id' value='" . htmlspecialchars($row['id']) . "'>
                                                                    <button type='submit' name='delete_zoom_meeting' class='btn btn-danger btn-sm'>Delete</button>
                                                                </form>
                                                            </td>";
                                                    echo "</tr>";
                                                }
                                                $result->free_result();
                                            } else {
                                                echo "<tr><td colspan='7'>Error fetching meetings: " . $mysqli->error . "</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('assets/inc/footer.php'); ?>
        </div>
    </div>
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>

</html>