<?php
session_start();
include('assets/inc/config.php');

// Check if doctor ID is set
if (!isset($_SESSION['doc_id'])) {
    echo "Doctor ID not found in session.";
    exit;
}

$doctor_id = $_SESSION['doc_id'];

// Handle Zoom Meeting Scheduling
if (isset($_POST['schedule_meeting'])) {
    $meeting_topic = filter_input(INPUT_POST, 'topic', FILTER_SANITIZE_STRING);
    $meeting_date = filter_input(INPUT_POST, 'meeting_date', FILTER_SANITIZE_STRING);
    $meeting_time = filter_input(INPUT_POST, 'meeting_time', FILTER_SANITIZE_STRING);
    $meeting_duration = filter_input(INPUT_POST, 'meeting_duration', FILTER_SANITIZE_NUMBER_INT);
    $meeting_id = filter_input(INPUT_POST, 'meeting_id', FILTER_SANITIZE_STRING);

    if (!$meeting_topic || !$meeting_date || !$meeting_time || !$meeting_duration || !$meeting_id) {
        $_SESSION['error_message'] = "Please fill in all fields.";
        header("Location: manage_doctor_zoom_meetings.php");
        exit;
    }

    // Convert meeting_date and meeting_time into a single DATETIME format
    $start_time = date('Y-m-d H:i:s', strtotime("$meeting_date $meeting_time"));

    $query = "INSERT INTO his_zoom_meetings (doctor_id, topic, meeting_date, start_time, duration, meeting_id) 
              VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = $mysqli->prepare($query);

    if ($stmt) {
        $stmt->bind_param('isssis', $doctor_id, $meeting_topic, $meeting_date, $start_time, $meeting_duration, $meeting_id);
        
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Meeting scheduled successfully.";
        } else {
            $_SESSION['error_message'] = "Error scheduling meeting: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $_SESSION['error_message'] = "Error preparing statement: " . $mysqli->error;
    }
    header("Location: manage_doctor_zoom_meetings.php");
    exit;
}

// Fetch Doctor's Meetings
$query = "SELECT * FROM his_zoom_meetings WHERE doctor_id = ? ORDER BY meeting_date DESC, start_time DESC";
$stmt = $mysqli->prepare($query);
$stmt->bind_param('i', $doctor_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php'); ?>

<body>
    <div id="wrapper">
        <?php include("assets/inc/nav.php"); ?>
        <?php include("assets/inc/sidebar.php"); ?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Manage Zoom Meetings</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">Scheduled Zoom Meetings</h4>

                                    <?php
                                    if (isset($_SESSION['success_message'])) {
                                        echo '<div class="alert alert-success">' . $_SESSION['success_message'] . '</div>';
                                        unset($_SESSION['success_message']);
                                    }
                                    if (isset($_SESSION['error_message'])) {
                                        echo '<div class="alert alert-danger">' . $_SESSION['error_message'] . '</div>';
                                        unset($_SESSION['error_message']);
                                    }
                                    ?>

                                    <form method="post">
                                        <input type="text" name="topic" placeholder="Meeting Topic" required><br>
                                        <input type="date" name="meeting_date" required><br>
                                        <input type="time" name="meeting_time" required><br>
                                        <input type="number" name="meeting_duration" placeholder="Duration (mins)" required><br>
                                        <input type="text" name="meeting_id" placeholder="Meeting ID" required><br>
                                        <button type="submit" name="schedule_meeting">Schedule Meeting</button>
                                    </form>

                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Topic</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                                <th>Duration</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while ($row = $result->fetch_assoc()) { ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($row['topic']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['meeting_date']); ?></td>
                                                    <td><?php echo date("H:i", strtotime($row['start_time'])); ?></td>
                                                    <td><?php echo htmlspecialchars($row['duration']); ?> mins</td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('assets/inc/footer.php'); ?>
        </div>
    </div>
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>

    <script>
        document.getElementById('consultationForm').addEventListener('submit', function() {
        alert("Appointment request submitted successfully!");
    });
    </script>
</body>

</html>
