<?php
    session_start();
    include('assets/inc/config.php');

    // Update Zoom Meeting (Doctors Only)
    if (isset($_POST['update_zoom_meeting'])) {
        $meeting_id = $_POST['meeting_id'];
        $topic = $_POST['meeting_title']; // Changed to match database column
        $meeting_date = $_POST['meeting_date'];
        $meeting_time = $_POST['meeting_time'];
        $duration = $_POST['meeting_duration'];
        $meeting_link = $_POST['meeting_link'];

        $query = "UPDATE his_zoom_meetings SET topic=?, meeting_date=?, meeting_time=?, duration=?, meeting_id=? WHERE id=? AND doctor_id=?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('sssisii', $topic, $meeting_date, $meeting_time, $duration, $meeting_link, $meeting_id, $_SESSION['doc_id']);
        
        if ($stmt->execute()) {
            echo "<script>alert('Meeting updated successfully!'); window.location.href='his_doc_alter_zoom_meeting.php';</script>";
        } else {
            echo "<script>alert('Error updating meeting: " . $stmt->error . "');</script>";
        }
        $stmt->close();
    }

    // Delete Zoom Meeting (Doctors Only)
    if (isset($_POST['delete_zoom_meeting'])) {
        $meeting_id = $_POST['meeting_id'];
        $query = "DELETE FROM his_zoom_meetings WHERE id=? AND doctor_id=?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('ii', $meeting_id, $_SESSION['doc_id']);
        
        if ($stmt->execute()) {
            echo "<script>alert('Meeting deleted successfully!'); window.location.href='his_doc_alter_zoom_meeting.php';</script>";
        } else {
            echo "<script>alert('Error deleting meeting: " . $stmt->error . "');</script>";
        }
        $stmt->close();
    }
?>
<!DOCTYPE html>
<html lang="en">
    <?php include('assets/inc/head.php'); ?>
    <body>
        <div id="wrapper">
            <?php include("assets/inc/nav.php"); ?>
            <?php include("assets/inc/sidebar.php"); ?>

            <div class="content-page">
                <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Manage Your Zoom Meetings</h4>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Your Scheduled Zoom Meetings</h4>
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Title</th>
                                                    <th>Date</th>
                                                    <th>Time</th>
                                                    <th>Duration</th>
                                                    <th>Link</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $query = "SELECT * FROM his_zoom_meetings WHERE doctor_id=?";
                                                    $stmt = $mysqli->prepare($query);
                                                    $stmt->bind_param('i', $_SESSION['doc_id']);
                                                    $stmt->execute();
                                                    $result = $stmt->get_result();
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo "<tr>";
                                                        echo "<td>" . $row['topic'] . "</td>";
                                                        echo "<td>" . $row['meeting_date'] . "</td>";
                                                        echo "<td>" . $row['meeting_time'] . "</td>";
                                                        echo "<td>" . $row['duration'] . " mins</td>";
                                                        echo "<td><a href='" . $row['meeting_id'] . "' target='_blank'>Join</a></td>";
                                                        echo "<td>
                                                                <form method='post' style='display:inline;'>
                                                                    <input type='hidden' name='meeting_id' value='" . $row['id'] . "'>
                                                                    <button type='submit' name='delete_zoom_meeting' class='btn btn-danger btn-sm'>Cancel</button>
                                                                </form>
                                                                <button class='btn btn-warning btn-sm' onclick=\"editMeeting('" . $row['id'] . "', '" . htmlspecialchars($row['topic'], ENT_QUOTES) . "', '" . $row['meeting_date'] . "', '" . $row['meeting_time'] . "', '" . $row['duration'] . "', '" . $row['meeting_id'] . "')\">Edit</button>
                                                            </td>";
                                                        echo "</tr>";
                                                    }
                                                ?>
                                            </tbody>
                                        </table>

                                        <!-- Edit Meeting Modal -->
                                        <div id="editMeetingModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Edit Zoom Meeting</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form method="post">
                                                            <input type="hidden" name="meeting_id" id="edit_meeting_id">
                                                            <div class="form-group">
                                                                <label>Meeting Title</label>
                                                                <input type="text" name="meeting_title" id="edit_meeting_title" class="form-control" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Meeting Date</label>
                                                                <input type="date" name="meeting_date" id="edit_meeting_date" class="form-control" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Meeting Time</label>
                                                                <input type="time" name="meeting_time" id="edit_meeting_time" class="form-control" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Duration (mins)</label>
                                                                <input type="number" name="meeting_duration" id="edit_meeting_duration" class="form-control" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Meeting Link</label>
                                                                <input type="url" name="meeting_link" id="edit_meeting_link" class="form-control" required>
                                                            </div>
                                                            <button type="submit" name="update_zoom_meeting" class="btn btn-success">Update Meeting</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <script>
                                            function editMeeting(id, title, date, time, duration, link) {
                                                document.getElementById("edit_meeting_id").value = id;
                                                document.getElementById("edit_meeting_title").value = title;
                                                document.getElementById("edit_meeting_date").value = date;
                                                document.getElementById("edit_meeting_time").value = time;
                                                document.getElementById("edit_meeting_duration").value = duration;
                                                document.getElementById("edit_meeting_link").value = link;
                                                $('#editMeetingModal').modal('show');
                                            }
                                        </script>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php include('assets/inc/footer.php'); ?>
            </div>
        </div>
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/js/app.min.js"></script>
    </body>
</html>
