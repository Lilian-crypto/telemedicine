<?php
session_start();
include('assets/inc/config.php');

// Check if doctor ID is set
if (!isset($_SESSION['doc_id'])) {
    die("Error: Doctor ID not found in session.");
}

$doctor_id = $_SESSION['doc_id'];

// Check if table exists before querying
$tableCheck = $mysqli->query("SHOW TABLES LIKE 'appointment_requests'");
if ($tableCheck->num_rows == 0) {
    die("Error: Table 'appointment_requests' does not exist.");
}

// Fetch appointments
$query = "SELECT * FROM appointment_requests ORDER BY submission_time DESC";
$stmt = $mysqli->prepare($query);
if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
} else {
    die("Error preparing query: " . $mysqli->error);
}
?>
<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php'); ?>
<body>
    <div id="wrapper">
        <?php include("assets/inc/nav.php"); ?>
        <?php include("assets/inc/sidebar.php"); ?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Patient Appointment Requests</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">View Appointment Requests</h4>
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Patient Name</th>
                                                <th>Email</th>
                                                <th>Phone Number</th>
                                                <th>Department</th>
                                                <th>Preferred Date & Time</th>
                                                <th>Reason for Consultation</th>
                                                <th>Submitted On</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . htmlspecialchars($row['request_id']) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['patient_name']) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['phone_number']) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['department']) . "</td>";
                                                    echo "<td>" . date("Y-m-d H:i", strtotime($row['preferred_datetime'])) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['consultation_reason']) . "</td>";
                                                    echo "<td>" . date("Y-m-d H:i", strtotime($row['submission_time'])) . "</td>";
                                                    echo "</tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='8'>No appointment requests found.</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('assets/inc/footer.php'); ?>
        </div>
    </div>
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>
</html>
