<?php
session_start();
include('assets/inc/config.php');

// Check if doctor ID is set
if (!isset($_SESSION['doc_id'])) {
    echo "Doctor ID not found in session.";
    exit;
}

$doctor_id = $_SESSION['doc_id'];

// Corrected SQL query using start_time instead of non-existent columns
$query = "SELECT * FROM his_zoom_meetings WHERE doctor_id = ? ORDER BY start_time DESC";
$stmt = $mysqli->prepare($query);

if ($stmt) {
    $stmt->bind_param('i', $doctor_id);
    if ($stmt->execute()) {
        $result = $stmt->get_result();
    } else {
        echo "Error executing query: " . $stmt->error;
        exit;
    }
    $stmt->close();
} else {
    echo "Error preparing statement: " . $mysqli->error;
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php'); ?>

<body>
    <div id="wrapper">
        <?php include("assets/inc/nav.php"); ?>
        <?php include("assets/inc/sidebar.php"); ?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Scheduled Zoom Meetings</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">View Scheduled Meetings</h4>
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Meeting Title</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                                <th>Duration (mins)</th>
                                                <th>Meeting Link</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . htmlspecialchars($row['topic']) . "</td>";
                                                    echo "<td>" . date("Y-m-d", strtotime($row['start_time'])) . "</td>";
                                                    echo "<td>" . date("H:i:s", strtotime($row['start_time'])) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['duration']) . "</td>";
                                                    echo "<td><a href='https://zoom.us/j/" . htmlspecialchars($row['meeting_id']) . "' target='_blank'>Join Meeting</a></td>";
                                                    echo "</tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='5'>No scheduled meetings found.</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('assets/inc/footer.php'); ?>
        </div>
    </div>
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>
</html>
