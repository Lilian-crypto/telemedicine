<?php
$dbuser = "root";  // Ensure it's "root" and not empty ('')
$dbpass = "";      // Ensure it's empty if no password is required
$host = "localhost";
$db = "hmisphp";

$mysqli = new mysqli($host, $dbuser, $dbpass, $db);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>
