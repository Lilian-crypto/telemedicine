<footer class="footer footer-alt">
             <?php echo date ('Y');?> &copy; Telemedicine.</a> 
</footer>