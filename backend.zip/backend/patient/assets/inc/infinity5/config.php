<?php
$host = "sql304.infinityfree.com"; // MySQL hostname
$username = "if0_38645621"; // MySQL username
$password = ""; // Empty password
$database = "hmisphp"; // DB name

$mysqli = new mysqli($host, $dbuser, $dbpass, $db);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>
