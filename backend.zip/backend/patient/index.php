<?php
session_start();
include('assets/inc/config.php'); // Get configuration file

// Handle login if form is submitted
if (isset($_POST['patient_login'])) {
    $patient_email = $_POST['patient_email'];
    $patient_pwd = $_POST['patient_pwd']; // Raw password entered by the user

    // Prepare SQL query to get the stored hashed password from the database
    $stmt = $mysqli->prepare("SELECT patient_email, patient_pwd, patient_id FROM his_patients WHERE patient_email=?");
    $stmt->bind_param('s', $patient_email); // Bind the email parameter
    $stmt->execute(); // Execute the statement
    $stmt->bind_result($db_email, $db_hashed_pwd, $patient_id); // Bind result columns
    $rs = $stmt->fetch(); // Fetch result

    if ($rs) {
        // Check if the entered password matches the hashed password in the database
        if (password_verify($patient_pwd, $db_hashed_pwd)) {
            // If password is correct, set session variables
            $_SESSION['patient_id'] = $patient_id;
            $_SESSION['patient_email'] = $db_email;
            header("Location: patient_dashboard.php"); // Redirect to dashboard
            exit;
        } else {
            $err = "Access Denied. Please Check Your Credentials"; // Error message for incorrect password
        }
    } else {
        $err = "No account found with this email"; // Error message if email doesn't exist
    }
}
?>

<!-- End Login -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Afya Hospital Telemedicine - Patient Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="" name="description" />
    <meta content="" name="MartDevelopers" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- Load Sweet Alert Javascript -->
    <script src="assets/js/swal.js"></script>
    <!-- Inject SWAL -->
    <?php if (isset($err)) { ?>
        <script>
            setTimeout(function () {
                swal("Failed", "<?php echo $err; ?>", "error");
            }, 100);
        </script>
    <?php } ?>
</head>

<body class="authentication-bg authentication-bg-pattern">

    <div class="account-pages mt-5 mb-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card bg-pattern">
                        <div class="card-body p-4">
                            <div class="text-center w-75 m-auto">
                                <a href="index.php">
                                    <span><img src="assets/images/logo-dark.png" alt="" height="22"></span>
                                </a>
                                <p class="text-muted mb-4 mt-3">Enter your email address and password to access your Patient portal.</p>
                            </div>

                            <form method="post">
                                <div class="form-group mb-3">
                                    <label for="emailaddress">Patient Email</label>
                                    <input class="form-control" name="patient_email" type="email" id="emailaddress" required="" placeholder="Enter your email address">
                                </div>

                                <div class="form-group mb-3">
                                    <label for="password">Password</label>
                                    <input class="form-control" name="patient_pwd" type="password" required="" id="password" placeholder="Enter your password">
                                </div>

                                <div class="form-group mb-0 text-center">
                                    <button class="btn btn-success btn-block" name="patient_login" type="submit">Patient Log In</button>
                                </div>
                            </form>

                        </div> <!-- end card-body -->
                    </div>
                    <!-- end card -->

                    <div class="row mt-3">
                        <div class="col-12 text-center">
                            <p> <a href="patient_reset_pwd.php" class="text-white-50 ml-1">Forgot your password?</a></p>
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                </div> <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end page -->

    <?php include("assets/inc/footer1.php"); ?>

    <!-- Vendor js -->
    <script src="assets/js/vendor.min.js"></script>

    <!-- App js -->
    <script src="assets/js/app.min.js"></script>

</body>

</html>
