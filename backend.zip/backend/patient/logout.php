<?php
session_start();
session_destroy(); // Destroy the session to log the patient out
header('Location: index.php'); // Redirect to login page
exit;
?>
