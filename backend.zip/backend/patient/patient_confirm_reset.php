<?php
session_start();
include('../../assets/inc/config.php');

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Check if token exists
    $query = "SELECT email FROM his_pwdresets WHERE token=? AND status='Pending'";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        die("Invalid or expired token.");
    } else {
        $row = $result->fetch_assoc();
        $email = $row['email'];
    }
}

if (isset($_POST['update_password'])) {
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
    $email = $_POST['email'];

    // Update patient's password
    $update_query = "UPDATE his_patients SET password=? WHERE email=?";
    $update_stmt = $mysqli->prepare($update_query);
    $update_stmt->bind_param('ss', $new_password, $email);
    $update_stmt->execute();

    if ($update_stmt) {
        // Mark reset request as used
        $delete_query = "DELETE FROM his_pwdresets WHERE email=?";
        $delete_stmt = $mysqli->prepare($delete_query);
        $delete_stmt->bind_param('s', $email);
        $delete_stmt->execute();

        $success = "Password updated successfully. You can now log in.";
    } else {
        $err = "Failed to reset password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Confirm Password Reset</title>
    <link href="../../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card bg-pattern">
                    <div class="card-body">
                        <div class="text-center">
                            <h4 class="text-muted">Reset Your Password</h4>
                        </div>
                        <form method="post">
                            <input type="hidden" name="email" value="<?php echo $email; ?>">
                            <div class="form-group">
                                <label>New Password</label>
                                <input class="form-control" name="new_password" type="password" required placeholder="Enter new password">
                            </div>
                            <div class="form-group text-center">
                                <button name="update_password" class="btn btn-success btn-block" type="submit"> Update Password </button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="text-center mt-3">
                    <a href="../index.php">Back to Login</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
