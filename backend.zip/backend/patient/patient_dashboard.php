<?php
session_start();
include('assets/inc/config.php'); // Database connection

// Ensure patient is logged in
if (!isset($_SESSION['patient_id'])) {
    header("Location: index.php");
    exit;
}

$patient_id = $_SESSION['patient_id']; 

// Default values
$first_name = $last_name = $phone = $address = $gender = $dob = "Not Available";
$default_profile_pic = "assets/images/users/patient.png"; 
$profile_pic = "";

// Fetch patient details
$query = "SELECT patient_first_name, patient_last_name, patient_phone, patient_address, patient_gender, date_of_birth, profile_pic FROM his_patients WHERE patient_id = ?";
$stmt = $mysqli->prepare($query);

if ($stmt) {
    $stmt->bind_param('i', $patient_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($first_name, $last_name, $phone, $address, $gender, $dob, $profile_pic);
        $stmt->fetch();
    }

    $stmt->close();
}

// Validate profile picture
$profile_image = (!empty($profile_pic) && file_exists("backend/patient/assets/images/users/" . basename($profile_pic))) 
    ? "backend/patient/assets/images/users/" . basename($profile_pic) 
    : $default_profile_pic;

    $zoom_link = null; // Default to null
    $zoom_query = "SELECT zoom_link FROM appointments WHERE patient_id = ? ORDER BY appointment_date DESC LIMIT 1";
    $zoom_stmt = $mysqli->prepare($zoom_query);
    
    if ($zoom_stmt) {
        $zoom_stmt->bind_param('i', $patient_id);
        $zoom_stmt->execute();
        $zoom_stmt->bind_result($zoom_link);
        $zoom_stmt->fetch();
        $zoom_stmt->close();
    }
    
    // Ensure $zoom_link has a default value if NULL
    $zoom_link = $zoom_link ?? "No appointment scheduled.";
    

// PayPal Payment Configuration
$paypal_url = "https://www.paypal.com/cgi-bin/webscr";
$paypal_business_email = "nyambural537@gmail.com";
$paypal_currency = "USD";
$appointment_fee = "50.00"; // Change this to your actual price
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin-bottom: 20px;
        }
        .card-body {
            text-align: center;
        }
        .list-group-item {
            cursor: pointer;
        }
        .btn-info {
            width: 100%;
        }
        .container {
            margin-top: 30px;
        }
        .zoom-section {
            margin-top: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
            border: 1px solid #ddd;
            text-align: center;
        }
        .paypal-button {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="card text-center">
                <img src="<?php echo htmlspecialchars($profile_image); ?>" class="card-img-top rounded-circle mx-auto mt-3" alt="Profile Picture">
                <div class="card-body">
                    <h5 class="card-title">Welcome, <?php echo htmlspecialchars($first_name . ' ' . $last_name); ?>!</h5>
                    <a href="profile.php" class="btn btn-primary btn-sm">Edit Profile</a>
                </div>
            </div>
            <ul class="list-group mt-3">
                <li class="list-group-item" onclick="window.location='view_appointments.php';">Appointments</li>
                <li class="list-group-item" onclick="window.location='view_prescriptions.php';">Prescriptions</li>
                <li class="list-group-item" onclick="window.location='view_medical_history.php';">Medical History</li>
                <li class="list-group-item" onclick="window.location='logout.php';">Logout</li>
            </ul>
        </div>

        <div class="col-md-9">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5>Welcome back, <?php echo htmlspecialchars($first_name . ' ' . $last_name); ?>!</h5>
                </div>
                <div class="card-body">
                    <p>Here is a quick overview of your medical activities:</p>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card text-center">
                                <div class="card-body">
                                    <h5>Appointments</h5>
                                    <p>View and manage your upcoming doctor appointments.</p>
                                    <a href="view_appointments.php" class="btn btn-info btn-sm">View</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-center">
                                <div class="card-body">
                                    <h5>Prescriptions</h5>
                                    <p>Access your prescribed medications and instructions.</p>
                                    <a href="view_prescriptions.php" class="btn btn-info btn-sm">View</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-center">
                                <div class="card-body">
                                    <h5>Medical History</h5>
                                    <p>Review your past diagnoses and treatments.</p>
                                    <a href="view_medical_history.php" class="btn btn-info btn-sm">View</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <div class="col-md-6">
                            <h6>Personal Information</h6>
                            <ul>
                                <li><strong>Phone:</strong> <?php echo htmlspecialchars($phone); ?></li>
                                <li><strong>Address:</strong> <?php echo htmlspecialchars($address); ?></li>
                                <li><strong>Gender:</strong> <?php echo htmlspecialchars($gender); ?></li>
                                <li><strong>Date of Birth:</strong> <?php echo htmlspecialchars($dob); ?></li>
                            </ul>
                        </div>
                    </div>

                    <!-- Zoom Appointment Section -->
                    <!-- <div class="zoom-section">
                        <h5>Zoom Appointment</h5>
                        <?php if (!empty($zoom_link)): ?>
                            <p><strong>Join Meeting:</strong> <a href="<?php echo htmlspecialchars($zoom_link); ?>" target="_blank"><?php echo htmlspecialchars($zoom_link); ?></a></p>
                        <?php else: ?>
                            <p>No Zoom appointment scheduled. Please check back later.</p>
                        <?php endif; ?> -->
                    </div>

                    <!-- PayPal Payment Button -->
                    <div class="paypal-button">
                        <h5>Pay for Appointment</h5>
                        <form action="<?php echo $paypal_url; ?>" method="post">
                            <input type="hidden" name="cmd" value="_xclick">
                            <input type="hidden" name="business" value="<?php echo $paypal_business_email; ?>">
                            <input type="hidden" name="item_name" value="Telemedicine Appointment">
                            <input type="hidden" name="amount" value="<?php echo $appointment_fee; ?>">
                            <input type="hidden" name="currency_code" value="<?php echo $paypal_currency; ?>">
                            <input type="hidden" name="return" value="http://localhost/Telemedicine/backend/patient/payment_success.php">
                            <input type="hidden" name="cancel_return" value="http://localhost/Telemedicine/backend/patient/payment_cancel.php">
                            <input type="submit" value="Pay Now" class="btn btn-success">
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
