<?php
session_start();
include('assets/inc/config.php');

if (isset($_POST['reset_pwd'])) {
    // Generate random password and token
    $email = $_POST['email'];
    $token = sha1(md5(uniqid(rand(), true)));
    $status = "Pending";
    $temp_pwd = substr(str_shuffle('0123456789QWERTYUIOPLKJHGFDSAZXCVBNMqwertyuioplkjhgfdsazxcvbnm'), 1, 10);

    // Insert into the database
    $query = "INSERT INTO his_pwdresets (email, token, status, pwd) VALUES(?, ?, ?, ?)";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('ssss', $email, $token, $status, $temp_pwd);
    $stmt->execute();

    if ($stmt) {
        $success = "Check your email for password reset instructions.";
    } else {
        $err = "Something went wrong. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Reset Password - Patient</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    
    <!-- SweetAlert -->
    <script src="assets/js/swal.js"></script>

    <!-- Inject SweetAlert Messages -->
    <?php if (isset($success)) { ?>
        <script>
            setTimeout(function () { 
                swal("Success", "<?php echo $success; ?>", "success");
            }, 100);
        </script>
    <?php } ?>

    <?php if (isset($err)) { ?>
        <script>
            setTimeout(function () { 
                swal("Error", "<?php echo $err; ?>", "error");
            }, 100);
        </script>
    <?php } ?>
</head>

<body class="authentication-bg authentication-bg-pattern">
    <div class="account-pages mt-5 mb-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card bg-pattern">
                        <div class="card-body p-4">
                            <div class="text-center w-75 m-auto">
                                <a href="patient_reset_pwd.php">
                                    <img src="assets/images/logo-dark.png" alt="" height="22">
                                </a>
                                <p class="text-muted mb-4 mt-3">
                                    Enter your email to receive password reset instructions.
                                </p>
                            </div>

                            <form method="post">
                                <div class="form-group mb-3">
                                    <label for="email">Email address</label>
                                    <input class="form-control" name="email" type="email" id="email" required placeholder="Enter your email">
                                </div>

                                <!-- Hidden Fields -->
                                <input type="hidden" name="token" value="<?php echo sha1(md5(uniqid(rand(), true))); ?>">
                                <input type="hidden" name="pwd" value="<?php echo substr(str_shuffle('0123456789QWERTYUIOPLKJHGFDSAZXCVBNMqwertyuioplkjhgfdsazxcvbnm'), 1, 10); ?>">
                                <input type="hidden" name="status" value="Pending">

                                <div class="form-group mb-0 text-center">
                                    <button name="reset_pwd" class="btn btn-primary btn-block" type="submit"> Reset Password </button>
                                </div>
                            </form>
                        </div> <!-- end card-body -->
                    </div> <!-- end card -->

                    <div class="row mt-3">
                        <div class="col-12 text-center">
                            <p class="text-white-50">Back to <a href="index.php" class="text-white ml-1"><b>Log in</b></a></p>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->
        </div> <!-- end container -->
    </div> <!-- end page -->

    <?php include("assets/inc/footer1.php"); ?>

    <!-- Vendor JS -->
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>
</html>
