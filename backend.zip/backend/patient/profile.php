<?php 
session_start();
include('assets/inc/config.php'); // Ensure database connection

// Ensure the patient is logged in
if (!isset($_SESSION['patient_id'])) {
    header("Location: index.php"); // Redirect if not logged in
    exit;
}

$patient_id = $_SESSION['patient_id'];

// Fetch patient details
$query = "SELECT patient_first_name, patient_last_name, patient_phone, patient_address, patient_gender, date_of_birth, profile_pic FROM his_patients WHERE patient_id = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param('i', $patient_id);
$stmt->execute();
$stmt->bind_result($first_name, $last_name, $phone, $address, $gender, $dob, $profile_pic);
$stmt->fetch();
$stmt->close();

// Set default profile picture if not available
$profile_image = !empty($profile_pic) ? "uploads/$profile_pic" : "assets/images/users/patient/default_profile.png";

// Create uploads directory if it does not exist
$upload_dir = 'uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true); // Create directory with full permissions
}

// Update Profile Logic
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_first_name = $_POST['first_name'];
    $new_last_name = $_POST['last_name'];
    $new_phone = $_POST['phone'];
    $new_address = $_POST['address'];
    $new_gender = $_POST['gender'];
    $new_dob = $_POST['dob'];
    $profile_pic_name = $profile_pic; // Default to existing picture

    // Handle profile picture upload
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
        $profile_pic_name = time() . "_" . basename($_FILES['profile_pic']['name']); // Unique name
        $profile_pic_tmp = $_FILES['profile_pic']['tmp_name'];
        $profile_pic_path = $upload_dir . $profile_pic_name;

        // Move the uploaded image to the uploads folder
        if (!move_uploaded_file($profile_pic_tmp, $profile_pic_path)) {
            die("Error: Unable to upload profile picture.");
        }
    }

    // Update database with or without profile picture
    if (!empty($profile_pic_name)) {
        $query = "UPDATE his_patients SET patient_first_name = ?, patient_last_name = ?, patient_phone = ?, patient_address = ?, patient_gender = ?, date_of_birth = ?, profile_pic = ? WHERE patient_id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('sssssssi', $new_first_name, $new_last_name, $new_phone, $new_address, $new_gender, $new_dob, $profile_pic_name, $patient_id);
    } else {
        $query = "UPDATE his_patients SET patient_first_name = ?, patient_last_name = ?, patient_phone = ?, patient_address = ?, patient_gender = ?, date_of_birth = ? WHERE patient_id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('ssssssi', $new_first_name, $new_last_name, $new_phone, $new_address, $new_gender, $new_dob, $patient_id);
    }

    if ($stmt->execute()) {
        // ✅ **Update session variables after profile update**
        $_SESSION['first_name'] = $new_first_name;
        $_SESSION['last_name'] = $new_last_name;
        $_SESSION['phone'] = $new_phone;
        $_SESSION['address'] = $new_address;
        $_SESSION['gender'] = $new_gender;
        $_SESSION['dob'] = $new_dob;
        $_SESSION['profile_pic'] = $profile_pic_name;

        // Redirect back to the dashboard after update
        header("Location: patient_dashboard.php");
        exit;
    } else {
        die("Error updating profile: " . $stmt->error);
    }
}
?>

<!-- Edit Profile Form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/dashboard.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h2>Edit Profile</h2>
    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="first_name">First Name</label>
            <input type="text" name="first_name" class="form-control" value="<?php echo htmlspecialchars($first_name); ?>" required>
        </div>
        <div class="form-group">
            <label for="last_name">Last Name</label>
            <input type="text" name="last_name" class="form-control" value="<?php echo htmlspecialchars($last_name); ?>" required>
        </div>
        <div class="form-group">
            <label for="phone">Phone</label>
            <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($phone); ?>" required>
        </div>
        <div class="form-group">
            <label for="address">Address</label>
            <input type="text" name="address" class="form-control" value="<?php echo htmlspecialchars($address); ?>" required>
        </div>
        <div class="form-group">
            <label for="gender">Gender</label>
            <select name="gender" class="form-control" required>
                <option value="Male" <?php echo $gender == 'Male' ? 'selected' : ''; ?>>Male</option>
                <option value="Female" <?php echo $gender == 'Female' ? 'selected' : ''; ?>>Female</option>
            </select>
        </div>
        <div class="form-group">
            <label for="dob">Date of Birth</label>
            <input type="date" name="dob" class="form-control" value="<?php echo htmlspecialchars($dob); ?>" required>
        </div>
        <div class="form-group">
            <label for="profile_pic">Profile Picture</label>
            <input type="file" name="profile_pic" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Save Changes</button>
    </form>
</div>

</body>
</html>
