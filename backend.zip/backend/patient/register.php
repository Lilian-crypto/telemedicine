<?php
session_start();
include('assets/inc/config.php'); // Include your database configuration file

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect and sanitize form data
    $first_name = mysqli_real_escape_string($mysqli, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($mysqli, $_POST['last_name']);
    $phone = mysqli_real_escape_string($mysqli, $_POST['phone']);
    $address = mysqli_real_escape_string($mysqli, $_POST['address']);
    $gender = mysqli_real_escape_string($mysqli, $_POST['gender']);
    $dob = mysqli_real_escape_string($mysqli, $_POST['dob']);
    $email = mysqli_real_escape_string($mysqli, $_POST['email']);
    $password = mysqli_real_escape_string($mysqli, $_POST['password']);
    $patient_type = mysqli_real_escape_string($mysqli, $_POST['patient_type']);
    $ailment = mysqli_real_escape_string($mysqli, $_POST['ailment']);
    $age = mysqli_real_escape_string($mysqli, $_POST['age']);

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare SQL query to insert new patient into the database
    $stmt = $mysqli->prepare("INSERT INTO his_patients (patient_email, patient_pwd, patient_first_name, patient_last_name, patient_phone, patient_address, patient_gender, date_of_birth, patient_type, patient_ailment, patient_age) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('ssssssssssi', $email, $hashed_password, $first_name, $last_name, $phone, $address, $gender, $dob, $patient_type, $ailment, $age);

    if ($stmt->execute()) {
        $success = "Registration successful. You can now log in.";
    } else {
        $error = "Error: " . $stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register New Patient</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css">
    <script src="assets/js/swal.js"></script>
    <?php if (isset($error)) { ?>
        <script>
            setTimeout(function() {
                swal("Error", "<?php echo $error; ?>", "error");
            }, 100);
        </script>
    <?php } ?>
    <?php if (isset($success)) { ?>
        <script>
            setTimeout(function() {
                swal("Success", "<?php echo $success; ?>", "success");
            }, 100);
        </script>
    <?php } ?>
</head>

<body class="authentication-bg authentication-bg-pattern">

    <div class="account-pages mt-5 mb-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card bg-pattern">
                        <div class="card-body p-4">
                            <div class="text-center w-75 m-auto">
                                <a href="index.php">
                                    <span><img src="assets/images/logo-dark.png" alt="" height="22"></span>
                                </a>
                                <p class="text-muted mb-4 mt-3">Fill in the form below to register as a new patient.</p>
                            </div>

                            <form method="post">
                                <div class="form-group mb-3">
                                    <label for="first_name">First Name</label>
                                    <input class="form-control" name="first_name" type="text" id="first_name" required placeholder="Enter your first name">
                                </div>

                                <div class="form-group mb-3">
                                    <label for="last_name">Last Name</label>
                                    <input class="form-control" name="last_name" type="text" id="last_name" required placeholder="Enter your last name">
                                </div>

                                <div class="form-group mb-3">
                                    <label for="phone">Phone</label>
                                    <input class="form-control" name="phone" type="text" id="phone" required placeholder="Enter your phone number">
                                </div>

                                <div class="form-group mb-3">
                                    <label for="address">Address</label>
                                    <input class="form-control" name="address" type="text" id="address" required placeholder="Enter your address">
                                </div>

                                <div class="form-group mb-3">
                                    <label for="gender">Gender</label>
                                    <select class="form-control" name="gender" id="gender" required>
                                        <option value="">Select your gender</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>

                                <div class="form-group mb-3">
                                    <label for="dob">Date of Birth</label>
                                    <input class="form-control" name="dob" type="date" id="dob" required>
                                </div>

                                <div class="form-group mb-3">
                                    <label for="email">Email</label>
                                    <input class="form-control" name="email" type="email" id="email" required placeholder="Enter your email address">
                                </div>

                                <div class="form-group mb-3">
                                    <label for="password">Password</label>
                                    <input class="form-control" name="password" type="password" id="password" required placeholder="Enter your password">
                                </div>

                                <div class="form-group mb-3">
                                    <label for="patient_type">Patient Type</label>
                                    <input class="form-control" name="patient_type" type="text" id="patient_type" required placeholder="Enter your patient type">
                                </div>

                                <div class="form-group mb-3">
                                    <label for="ailment">Patient Ailment</label>
                                    <input class="form-control" name="ailment" type="text" id="ailment" required placeholder="Enter your ailment">
                                </div>

                                <div class="form-group mb-3">
                                    <label for="age">Patient Age</label>
                                    <input class="form-control" name="age" type="number" id="age" required placeholder="Enter your age">
                                </div>

                                <div class="form-group mb-0 text-center">
                                   
                                <div class="form-group mb-0 text-center">
                                <button type="submit" class="btn btn-primary btn-block" name="register">Register</button>
                                    <a href="index.php" class="btn btn-link btn-block">Already have an account? Log In</a>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- end card -->
                </div>
            </div>
        </div>
    </div>

    <!-- JAVASCRIPT -->
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>

</html>
