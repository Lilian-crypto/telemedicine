<?php
session_start();
include('assets/inc/config.php'); // Database connection

// Ensure the request is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patient_id = $_POST['patient_id'] ?? null;
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $gender = trim($_POST['gender'] ?? '');
    $dob = trim($_POST['dob'] ?? '');

    // Ensure user is authorized
    if ($_SESSION['patient_id'] != $patient_id) {
        header("Location: profile.php?error=UnauthorizedAction");
        exit;
    }

    // Validate required fields
    if (!$patient_id || empty($first_name) || empty($last_name) || empty($phone)) {
        header("Location: profile.php?error=RequiredFieldsMissing");
        exit;
    }

    // Handle profile picture upload
    $profile_pic = '';
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
        $target_dir = "uploads/profile_pics/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);

        $file_name = basename($_FILES["profile_pic"]["name"]);
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($file_ext, $allowed_exts)) {
            $profile_pic = $target_dir . "patient_" . $patient_id . "." . $file_ext;
            
            // Move file and check if upload was successful
            if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $profile_pic)) {
                error_log("File uploaded successfully: " . $profile_pic);
            } else {
                error_log("File upload failed!");
            }
        }
    }

    // SQL query to update profile
    if ($profile_pic) {
        $query = "UPDATE patients SET patient_first_name = ?, patient_last_name = ?, patient_phone = ?, patient_address = ?, patient_gender = ?, date_of_birth = ?, profile_pic = ? WHERE patient_id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('sssssssi', $first_name, $last_name, $phone, $address, $gender, $dob, $profile_pic, $patient_id);
    } else {
        $query = "UPDATE patients SET patient_first_name = ?, patient_last_name = ?, patient_phone = ?, patient_address = ?, patient_gender = ?, date_of_birth = ? WHERE patient_id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('ssssssi', $first_name, $last_name, $phone, $address, $gender, $dob, $patient_id);
    }

    if ($stmt->execute()) {
        // Fetch updated data
        $stmt->close();

        $query = "SELECT patient_first_name, patient_last_name, patient_phone, patient_address, patient_gender, date_of_birth, profile_pic FROM patients WHERE patient_id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("i", $patient_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();

            // Update session variables
            $_SESSION['first_name'] = $user['patient_first_name'];
            $_SESSION['last_name'] = $user['patient_last_name'];
            $_SESSION['phone'] = $user['patient_phone'];
            $_SESSION['address'] = $user['patient_address'];
            $_SESSION['gender'] = $user['patient_gender'];
            $_SESSION['dob'] = $user['date_of_birth'];
            if (!empty($user['profile_pic'])) {
                $_SESSION['profile_pic'] = $user['profile_pic'] . '?v=' . time(); // Prevents caching issues
            }
        }

        header("Location: patient_dashboard.php?success=ProfileUpdated");
        exit;
    } else {
        error_log("Error updating record: " . $stmt->error);
        header("Location: profile.php?error=" . urlencode("Error updating record: " . $stmt->error));
        exit;
    }

    $stmt->close();
} else {
    header("Location: profile.php?error=InvalidRequest");
    exit;
}
?>
