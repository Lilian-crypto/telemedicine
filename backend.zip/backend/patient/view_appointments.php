<?php
session_start();
include('assets/inc/config.php');

if (!isset($_SESSION['patient_id'])) {
    header("Location: index.php");
    exit;
}

$patient_id = $_SESSION['patient_id'];

$query = "SELECT a.appointment_date, d.doc_fname, d.doc_lname, a.status, a.zoom_link
          FROM appointments a
          LEFT JOIN his_docs d ON a.doctor_id = d.doc_id 
          WHERE a.patient_id = ?";

$stmt = $mysqli->prepare($query);
$stmt->bind_param('i', $patient_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Appointments</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h2 class="mb-4">Your Appointments</h2>
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>Appointment Date</th>
                <th>Doctor</th>
                <th>Status</th>
                <th>Zoom Appointment</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo htmlspecialchars($row['appointment_date']); ?></td>
                <td>
                    <?php 
                        if (!empty($row['doc_fname']) && !empty($row['doc_lname'])) {
                            echo htmlspecialchars($row['doc_fname'] . ' ' . $row['doc_lname']);
                        } else {
                            echo '<span class="text-danger">No Doctor Assigned</span>';
                        }
                    ?>
                </td>
                <td><?php echo htmlspecialchars($row['status']); ?></td>
                <td>
                    <?php if (!empty($row['zoom_link'])) { ?>
                        <a href="<?php echo htmlspecialchars($row['zoom_link']); ?>" target="_blank" class="btn btn-primary btn-sm">
                            Join Meeting
                        </a>
                    <?php } else { ?>
                        <span class="text-muted">No Zoom Link</span>
                    <?php } ?>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>
