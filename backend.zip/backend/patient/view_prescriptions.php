<?php
session_start();
include('assets/inc/config.php');

if (!isset($_SESSION['patient_id'])) {
    header("Location: index.php");
    exit;
}

$patient_id = $_SESSION['patient_id'];
$query = "SELECT * FROM prescriptions WHERE patient_id = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param('i', $patient_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prescriptions</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <h2>Your Prescriptions</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Prescription Date</th>
                <th>Medication</th>
                <th>Dosage</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['prescribed_date']; ?></td>
                <td><?php echo $row['medication']; ?></td>
                <td><?php echo $row['dosage']; ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>
